export const deliveryData = [
	{
		town: 'Stavropol',
		cost: 500
	},
	{
		town: 'Moscow',
		cost: 300
	}
];
