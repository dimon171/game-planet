self.__precacheManifest = [
  {
    "url": "/assets/js/app-bb0ecba92ff26365f5b8.js"
  },
  {
    "revision": "64546219f427965a1e57",
    "url": "/assets/css/bundle-1b91c4f5b62de16c1de3.css"
  },
  {
    "url": "/assets/js/theme-64546219f427965a1e57.js"
  }
];